public class comparisonop {
    
    public static void main(String[] args) {
        
        int x = 5;
        int y = 3;

        System.out.println(x < y);
        System.out.println(x==y);
        System.out.println(x!=y);
        System.out.println(x>y);
        System.out.println(x>=y);
        System.out.println(x<=y);
        
    }
}
