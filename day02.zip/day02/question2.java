

class question2 {
     public static void main(String[] args) {
         
        float a = 14.5f;

        if (a > 10) {
            
            System.out.println("Good");

        } else {

            System.out.println("Bad");

        }

        a = 9;

        if (a > 10) {
            
            System.out.println("Good");

        } else {

            System.out.println("Bad");

        }

     }

     
}
