public class PrintNumberFor {
    
    public static void main(String[] args) {
        
        for (int i = 0; i < 6; i++) {
            System.out.println(i);

        }

        for (int i = 15; i >  0; i--) {
            
            System.out.println(i);

        }

    }

}
