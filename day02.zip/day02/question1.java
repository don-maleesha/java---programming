class question1 {
    public static void main(String[] args) {
        
        int a;
        int b;
        int c;

        a = 20;
        b = 10;
        c = 3;

        System.out.print("Addition: ");
        System.out.println(a + b);

        System.out.print("Subtraction: ");
        System.out.println(a - b);

        System.out.print("Multiplication: ");
        System.out.println(a * b);

        System.out.print("Division: ");
        System.out.println(a / b);

        System.out.print("Remainder: ");
        System.out.println(a % c);
    }
}