
import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);

        System.out.println("Enter two numbers: ");
        int a = input.nextInt();
        int b = input.nextInt();

        Calculator calculator = new Calculator();
        calculator.add(a, b);
        calculator.subtract(a, b);
        calculator.multiply(a, b);
        calculator.divide(a, b);

        input.close();
    }
}
