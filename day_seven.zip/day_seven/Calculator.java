package day07;

public class Calculator {
    
    public int add(int a, int b) {
        System.out.println("Addition: " + (a + b));
        return a + b;
    }

    public float add(float a, float b) {
        System.out.println("Addition: " + (a + b));
        return a + b;
    }

    public int subtract(int a, int b) {
        System.out.println("Subtraction: " + (a - b));
        return a - b;
    }

    public float subtract(float a, float b) {
        System.out.println("Subtraction: " + (a - b));
        return a - b;
    }

    public int multiply(int a, int b) {
        System.out.println("Multiplication: " + (a * b));
        return a * b;
    }

    public float multiply(float a, float b) {
        System.out.println("Multiplication: " + (a * b));
        return a * b;
    }

    public int divide(int a, int b) {
        System.out.println("Division: " + (a / b));
        return a / b;
    }

    public float divide(float a, float b) {
        System.out.println("Division: " + (a / b));
        return a / b;
    }

    
}